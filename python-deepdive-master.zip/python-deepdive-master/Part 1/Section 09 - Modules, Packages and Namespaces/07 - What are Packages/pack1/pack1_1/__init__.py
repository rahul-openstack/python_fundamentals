

print('executing pack1_1...')
value = 'pack1_1 value'

import pack1.pack1_1.module1_1a
import pack1.pack1_1.module1_1b
